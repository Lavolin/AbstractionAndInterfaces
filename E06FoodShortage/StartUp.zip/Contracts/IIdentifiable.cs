﻿namespace E06FoodShortage
{
    public interface IIdentifiable
    {
        string Id { get; set; }
    }
}
