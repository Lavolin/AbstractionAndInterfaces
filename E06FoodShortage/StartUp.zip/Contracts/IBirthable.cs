﻿namespace E06FoodShortage
{
    public interface IBirthable
    {
        string Birhtdate { get; set; }
    }
}
